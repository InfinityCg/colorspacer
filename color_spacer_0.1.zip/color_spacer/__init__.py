# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Color Spacer",
    "author" : "Siddharth - Infinitycg.in", 
    "description" : "Helps you automatically set the color space of your images based on custom tags",
    "blender" : (3, 0, 0),
    "version" : (0, 1, 0),
    "location" : "View 3d",
    "warning" : "",
    "doc_url": "infinitycg.in", 
    "tracker_url": "infinitycg.in", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
nodetree = {'sna_color': '', }
class SNA_PT_COLOR_SPACE_SELECT_8FCC5(bpy.types.Panel):
    bl_label = 'Color space select'
    bl_idname = 'SNA_PT_COLOR_SPACE_SELECT_8FCC5'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Color Spacer'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_AFC8A = layout.box()
        box_AFC8A.alert = False
        box_AFC8A.enabled = True
        box_AFC8A.active = True
        box_AFC8A.use_property_split = False
        box_AFC8A.use_property_decorate = False
        box_AFC8A.alignment = 'Expand'.upper()
        box_AFC8A.scale_x = 1.0
        box_AFC8A.scale_y = 1.0
        box_AFC8A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_AFC8A.prop(bpy.context.scene, 'sna_color_space_choice', text='Color space', icon_value=0, emboss=True)
        box_64AF1 = layout.box()
        box_64AF1.alert = False
        box_64AF1.enabled = True
        box_64AF1.active = True
        box_64AF1.use_property_split = False
        box_64AF1.use_property_decorate = True
        box_64AF1.alignment = 'Expand'.upper()
        box_64AF1.scale_x = 1.0
        box_64AF1.scale_y = 1.2400000095367432
        box_64AF1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if (bpy.context.scene.sna_color_space_choice == 'ACES'):
            box_64AF1.prop(bpy.context.scene, 'sna_base_clr_enum', text='Color', icon_value=0, emboss=True)
        else:
            if (bpy.context.scene.sna_color_space_choice == 'Blender default'):
                box_64AF1.prop(bpy.context.scene, 'sna_blender_default_color', text='Color', icon_value=0, emboss=True)
        if (bpy.context.scene.sna_color_space_choice == 'ACES'):
            box_64AF1.prop(bpy.context.scene, 'sna_non__clr_enum', text='Non Color', icon_value=0, emboss=True)
        else:
            if (bpy.context.scene.sna_color_space_choice == 'Blender default'):
                box_64AF1.prop(bpy.context.scene, 'sna_blender_default_nc', text='Non Color', icon_value=0, emboss=True)
        if (bpy.context.scene.sna_color_space_choice == 'ACES'):
            box_64AF1.prop(bpy.context.scene, 'sna_cs_custom', text='Custom', icon_value=0, emboss=True)
        else:
            if (bpy.context.scene.sna_color_space_choice == 'Blender default'):
                box_64AF1.prop(bpy.context.scene, 'sna_blender_default_custom1', text='Custom', icon_value=0, emboss=True)
        if (bpy.context.scene.sna_color_space_choice == 'ACES'):
            box_64AF1.prop(bpy.context.scene, 'sna_cs_custom_2', text='Custom 2', icon_value=0, emboss=True)
        else:
            if (bpy.context.scene.sna_color_space_choice == 'Blender default'):
                box_64AF1.prop(bpy.context.scene, 'sna_blender_default_custom2', text='Custom 2', icon_value=0, emboss=True)
        box_50B06 = layout.box()
        box_50B06.alert = False
        box_50B06.enabled = True
        box_50B06.active = True
        box_50B06.use_property_split = False
        box_50B06.use_property_decorate = True
        box_50B06.alignment = 'Expand'.upper()
        box_50B06.scale_x = 1.0
        box_50B06.scale_y = 1.5399999618530273
        box_50B06.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = box_50B06.operator('sna.fix_space_b4bfa', text='Magic', icon_value=227, emboss=True, depress=False)
        box_4558A = layout.box()
        box_4558A.alert = False
        box_4558A.enabled = True
        box_4558A.active = True
        box_4558A.use_property_split = False
        box_4558A.use_property_decorate = True
        box_4558A.alignment = 'Expand'.upper()
        box_4558A.scale_x = 1.0
        box_4558A.scale_y = 1.5399999618530273
        box_4558A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = box_4558A.operator('sna.open_preferences_42998', text='Edit Tags', icon_value=121, emboss=False, depress=False)


class SNA_OT_Open_Preferences_42998(bpy.types.Operator):
    bl_idname = "sna.open_preferences_42998"
    bl_label = "Open preferences"
    bl_description = "Opens the preference window to edit tags"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.screen.userpref_show()
        bpy.context.preferences.active_section = 'ADDONS'
        bpy.data.window_managers["WinMan"].addon_search = "Color spacer"
        bpy.ops.preferences.addon_expand(module="color_spacer")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_AddonPreferences_D9AB8(bpy.types.AddonPreferences):
    bl_idname = 'color_spacer'
    sna_preprop_tags_base: bpy.props.StringProperty(name='preprop_tags_base', description='', options={'TEXTEDIT_UPDATE'}, default='base albedo ', subtype='NONE', maxlen=0)
    sna_preprop_tags_nonclr: bpy.props.StringProperty(name='preprop_tags_nonclr', description='', options={'TEXTEDIT_UPDATE'}, default='normal roughness gloss', subtype='NONE', maxlen=0)
    sna_preprop_tags_custom1: bpy.props.StringProperty(name='preprop_tags_custom1', description='', options={'TEXTEDIT_UPDATE'}, default='custom ', subtype='NONE', maxlen=0)
    sna_preprop_tags_custom2: bpy.props.StringProperty(name='preprop_tags_custom2', description='', options={'TEXTEDIT_UPDATE'}, default='custom2 ', subtype='NONE', maxlen=0)

    def sna_color_space_choice_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_color_space_choice: bpy.props.EnumProperty(name='Color Space Choice', description='', options={'HIDDEN'}, items=[('ACES', 'ACES', '', 0, 0), ('Agx', 'Agx', '', 0, 1), ('Blender default', 'Blender default', '', 0, 2)])

    def draw(self, context):
        if not (False):
            layout = self.layout 
            col_B324D = layout.column(heading='', align=True)
            col_B324D.alert = False
            col_B324D.enabled = True
            col_B324D.active = True
            col_B324D.use_property_split = False
            col_B324D.use_property_decorate = False
            col_B324D.scale_x = 1.0
            col_B324D.scale_y = 1.2400000095367432
            col_B324D.alignment = 'Expand'.upper()
            col_B324D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_B324D.label(text='Tags', icon_value=742)
            col_B324D.label(text='All lowercase, Separated by space', icon_value=110)
            layout.prop(bpy.context.preferences.addons['color_spacer'].preferences, 'sna_preprop_tags_base', text='Color data', icon_value=0, emboss=True)
            layout.prop(bpy.context.preferences.addons['color_spacer'].preferences, 'sna_preprop_tags_nonclr', text='Non color data', icon_value=0, emboss=True)
            layout.prop(bpy.context.preferences.addons['color_spacer'].preferences, 'sna_preprop_tags_custom1', text='Custom 1', icon_value=0, emboss=True)
            layout.prop(bpy.context.preferences.addons['color_spacer'].preferences, 'sna_preprop_tags_custom2', text='Custom 2', icon_value=0, emboss=True)


class SNA_OT_Fix_Space_B4Bfa(bpy.types.Operator):
    bl_idname = "sna.fix_space_b4bfa"
    bl_label = "fix space"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        base = bpy.context.preferences.addons['color_spacer'].preferences.sna_preprop_tags_base
        cs_rgb = (bpy.context.scene.sna_blender_default_color if (bpy.context.scene.sna_color_space_choice == 'Blender default') else bpy.context.scene.sna_base_clr_enum)
        nonclr = bpy.context.preferences.addons['color_spacer'].preferences.sna_preprop_tags_nonclr
        cs_nonclr = (bpy.context.scene.sna_blender_default_nc if (bpy.context.scene.sna_color_space_choice == 'Blender default') else bpy.context.scene.sna_non__clr_enum)
        custom = bpy.context.preferences.addons['color_spacer'].preferences.sna_preprop_tags_custom1
        cs_custom = (bpy.context.scene.sna_blender_default_custom1 if (bpy.context.scene.sna_color_space_choice == 'Blender default') else bpy.context.scene.sna_cs_custom)
        custom_two = bpy.context.preferences.addons['color_spacer'].preferences.sna_preprop_tags_custom2
        cs_custom_two = (bpy.context.scene.sna_blender_default_custom2 if (bpy.context.scene.sna_color_space_choice == 'Blender default') else bpy.context.scene.sna_cs_custom_2)
        Variable = None
        for img in bpy.data.images:
            imgname = f"{img.name}"
            imgnamec = imgname.lower()
            if any(c in imgnamec for c in base.split() ):
                bpy.data.images[imgname].colorspace_settings.name = cs_rgb
                print('success')
            elif any(c in imgnamec for c in nonclr.split() ):
                  bpy.data.images[imgname].colorspace_settings.name = cs_nonclr
                  print('success1')
            elif any(c in imgnamec for c in custom.split() ):
                  bpy.data.images[imgname].colorspace_settings.name = cs_custom
                  print('success2')
            elif any(c in imgnamec for c in custom_two.split() ):
                  bpy.data.images[imgname].colorspace_settings.name = cs_custom_two
                  print('success3')
            else:
                print('not found')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_color_space_choice_enum_items(self, context):
    return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_base_clr_enum = bpy.props.EnumProperty(name='Base clr enum', description='', options={'HIDDEN'}, items=[('Output - sRGB', 'Output - sRGB', '', 0, 0), ('role_matte_paint', 'role_matte_paint', '', 0, 1), ('role_data', 'role_data', '', 0, 2), ('Utility - Linear - sRGB', 'Utility - Linear - sRGB', '', 0, 3), ('Utility - sRGB - Texture', 'Utility - sRGB - Texture', '', 0, 4)])
    bpy.types.Scene.sna_non__clr_enum = bpy.props.EnumProperty(name='Non  clr enum', description='', options={'HIDDEN'}, items=[('Output - sRGB', 'Output - sRGB', '', 0, 0), ('role_matte_paint', 'role_matte_paint', '', 0, 1), ('role_data', 'role_data', '', 0, 2), ('Utility - Linear - sRGB', 'Utility - Linear - sRGB', '', 0, 3), ('Utility - sRGB - Texture', 'Utility - sRGB - Texture', '', 0, 4)])
    bpy.types.Scene.sna_cs_custom = bpy.props.EnumProperty(name='cs_custom', description='', options={'HIDDEN'}, items=[('Output - sRGB', 'Output - sRGB', '', 0, 0), ('role_matte_paint', 'role_matte_paint', '', 0, 1), ('role_data', 'role_data', '', 0, 2), ('Utility - Linear - sRGB', 'Utility - Linear - sRGB', '', 0, 3), ('Utility - sRGB - Texture', 'Utility - sRGB - Texture', '', 0, 4)])
    bpy.types.Scene.sna_cs_custom_2 = bpy.props.EnumProperty(name='cs_custom 2', description='', options={'HIDDEN'}, items=[('Output - sRGB', 'Output - sRGB', '', 0, 0), ('role_matte_paint', 'role_matte_paint', '', 0, 1), ('role_data', 'role_data', '', 0, 2), ('Utility - Linear - sRGB', 'Utility - Linear - sRGB', '', 0, 3), ('Utility - sRGB - Texture', 'Utility - sRGB - Texture', '', 0, 4)])
    bpy.types.Scene.sna_color_space_choice = bpy.props.EnumProperty(name='Color space choice', description='', items=[('ACES', 'ACES', '', 0, 0), ('Blender default', 'Blender default', '', 0, 1)])
    bpy.types.Scene.sna_blender_default_color = bpy.props.EnumProperty(name='Blender default_color', description='', options={'HIDDEN'}, items=[('sRGB', 'sRGB', '', 0, 0), ('Filmic sRGB', 'Filmic sRGB', '', 0, 1)])
    bpy.types.Scene.sna_blender_default_nc = bpy.props.EnumProperty(name='Blender default_nc', description='', options={'HIDDEN'}, items=[('Non-Color', 'Non-Color', '', 0, 0), ('Raw', 'Raw', '', 0, 1), ('Linear', 'Linear', '', 0, 2), ('Linear ACEScg', 'Linear ACEScg', '', 0, 3), ('Linear ACES', 'Linear ACES', '', 0, 4), ('XYZ', 'XYZ', '', 0, 5)])
    bpy.types.Scene.sna_blender_default_custom1 = bpy.props.EnumProperty(name='Blender default_Custom1', description='', options={'HIDDEN'}, items=[('sRGB', 'sRGB', '', 0, 0), ('Filmic sRGB', 'Filmic sRGB', '', 0, 1), ('Non-Color', 'Non-Color', '', 0, 2), ('Raw', 'Raw', '', 0, 3), ('Linear', 'Linear', '', 0, 4), ('Linear ACEScg', 'Linear ACEScg', '', 0, 5), ('Linear ACES', 'Linear ACES', '', 0, 6), ('XYZ', 'XYZ', '', 0, 7), ('Filmic Log', 'Filmic Log', '', 0, 8)])
    bpy.types.Scene.sna_blender_default_custom2 = bpy.props.EnumProperty(name='Blender default_Custom2', description='', options={'HIDDEN'}, items=[('sRGB', 'sRGB', '', 0, 0), ('Filmic sRGB', 'Filmic sRGB', '', 0, 1), ('Non-Color', 'Non-Color', '', 0, 2), ('Raw', 'Raw', '', 0, 3), ('Linear', 'Linear', '', 0, 4), ('Linear ACEScg', 'Linear ACEScg', '', 0, 5), ('Linear ACES', 'Linear ACES', '', 0, 6), ('XYZ', 'XYZ', '', 0, 7), ('Filmic Log', 'Filmic Log', '', 0, 8)])
    bpy.utils.register_class(SNA_PT_COLOR_SPACE_SELECT_8FCC5)
    bpy.utils.register_class(SNA_OT_Open_Preferences_42998)
    bpy.utils.register_class(SNA_AddonPreferences_D9AB8)
    bpy.utils.register_class(SNA_OT_Fix_Space_B4Bfa)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.fix_space_b4bfa', 'Y', 'PRESS',
        ctrl=True, alt=False, shift=True, repeat=False)
    addon_keymaps['645A5'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_blender_default_custom2
    del bpy.types.Scene.sna_blender_default_custom1
    del bpy.types.Scene.sna_blender_default_nc
    del bpy.types.Scene.sna_blender_default_color
    del bpy.types.Scene.sna_color_space_choice
    del bpy.types.Scene.sna_cs_custom_2
    del bpy.types.Scene.sna_cs_custom
    del bpy.types.Scene.sna_non__clr_enum
    del bpy.types.Scene.sna_base_clr_enum
    bpy.utils.unregister_class(SNA_PT_COLOR_SPACE_SELECT_8FCC5)
    bpy.utils.unregister_class(SNA_OT_Open_Preferences_42998)
    bpy.utils.unregister_class(SNA_AddonPreferences_D9AB8)
    bpy.utils.unregister_class(SNA_OT_Fix_Space_B4Bfa)
